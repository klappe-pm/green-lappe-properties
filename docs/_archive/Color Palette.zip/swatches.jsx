/* global React */
const { useState } = React;

// ---------- Palette data ----------
const PRIMITIVES = [
  { name: "Cedar",  hex: "#2D6A4F", role: "Primary brand",          material: "Pacific Northwest evergreen, painted shutter green" },
  { name: "Ink",    hex: "#1F2A2E", role: "Text, deep contrast",    material: "Slate, near-black with cool undertone" },
  { name: "Cream",  hex: "#FBF6EC", role: "Marketing surface",      material: "Printed brochure paper, warm off-white" },
  { name: "Paper",  hex: "#F7F5F0", role: "Product surface",        material: "Bank statement paper, cooler off-white" },
  { name: "Stone",  hex: "#D4D1CA", role: "Neutral mid-tone",       material: "Dividers, borders, decorative shapes" },
  { name: "Clay",   hex: "#A95C42", role: "Action accent",          material: "Oxidized terracotta, weathered cedar stain" },
  { name: "Sky",    hex: "#7BA7B8", role: "Secondary accent",       material: "Hydrangea blue-grey, calm informational" },
];

const DERIVED = [
  {
    token: "ink-80", hex: "#3D4A4E", ratio: 9.6, badge: "AAA",
    role: "Body emphasis & secondary headings.",
    demo: {
      kind: "text",
      heading: "Secondary heading.",
      body:    "Body emphasis lives at this color.",
    },
  },
  {
    token: "ink-60", hex: "#5C6A6E", ratio: 5.7, badge: "AA",
    role: "Metadata, captions, helper text.",
    demo: {
      kind: "text",
      heading: "Caption text.",
      body:    "Prepared 14 Mar 2026 · 14 pages",
    },
  },
  {
    token: "ink-40", hex: "#8A9498", ratio: 3.0, badge: "AA·LG",
    role: "Disabled text (large only), decorative.",
    demo: {
      kind: "text",
      heading: "Disabled.",
      body:    "Large text only — fails AA body.",
    },
  },
  {
    token: "ink-20", hex: "#C2C8CA", ratio: 1.4, badge: "Non-text",
    role: "Dividers, borders — never text.",
    demo: { kind: "divider" },
  },
];

// ---------- Utilities ----------
function hexToRgb(hex){
  const h = hex.replace('#','');
  return [0,2,4].map(i => parseInt(h.slice(i,i+2),16));
}
function relLum([r,g,b]){
  const f = v => { v/=255; return v<=0.03928 ? v/12.92 : Math.pow((v+0.055)/1.055, 2.4); };
  const [R,G,B] = [f(r),f(g),f(b)];
  return 0.2126*R + 0.7152*G + 0.0722*B;
}
function contrast(hexA, hexB){
  const la = relLum(hexToRgb(hexA));
  const lb = relLum(hexToRgb(hexB));
  const [hi,lo] = la>lb ? [la,lb] : [lb,la];
  return (hi + 0.05) / (lo + 0.05);
}
function onColor(hex){
  // Pick Ink or Cream as foreground depending on contrast
  return contrast(hex, "#1F2A2E") >= contrast(hex, "#FBF6EC") ? "#1F2A2E" : "#FBF6EC";
}

// Candidate foregrounds we ever pair text with.
// For each primitive card we list only the foregrounds that PASS AA body.
const FG_CANDIDATES = [
  { name: "Ink",   hex: "#1F2A2E" },
  { name: "Cream", hex: "#FBF6EC" },
  { name: "Cedar", hex: "#2D6A4F" },
  { name: "Clay",  hex: "#A95C42" },
];
function passingPairs(hex){
  return FG_CANDIDATES
    .filter(p => p.hex.toLowerCase() !== hex.toLowerCase())
    .map(p => ({ ...p, ratio: contrast(hex, p.hex) }))
    .filter(p => p.ratio >= 4.5)
    .sort((a, b) => b.ratio - a.ratio)
    .slice(0, 3);
}
function aaBadge(ratio){
  if (ratio >= 7)  return "AAA";
  if (ratio >= 4.5) return "AA";
  if (ratio >= 3)  return "AA·LG";
  return "—";
}

// ---------- Primitive swatch card ----------
function PrimitiveCard({ c, index }){
  const fg = onColor(c.hex);
  const pairs = passingPairs(c.hex);
  return (
    <article className="prim" style={{ background: c.hex, color: fg }}>
      <header className="prim__head">
        <span className="prim__index">P/{String(index+1).padStart(2,'0')}</span>
        <span className="prim__role">{c.role}</span>
      </header>

      <div className="prim__name-row">
        <h3 className="prim__name">{c.name}</h3>
        <div className="prim__chips" aria-hidden="true">
          <span className="prim__chip" style={{ background: "#FBF6EC" }}></span>
          <span className="prim__chip" style={{ background: "#1F2A2E" }}></span>
        </div>
      </div>

      <div className="prim__material-block">
        <span className="prim__material-label">Material reference</span>
        <p className="prim__material">{c.material}</p>
      </div>

      <footer className="prim__foot">
        <div className="prim__hex">
          <span className="prim__hex-label">HEX</span>
          <span className="prim__hex-val">{c.hex.toUpperCase()}</span>
        </div>
        <dl className="prim__ratios" aria-label="Foregrounds that pass AA body on this swatch">
          {pairs.length > 0 ? (
            <>
              <div className="prim__ratios-head"><dt>Pairs with</dt><dd>AA ratio</dd></div>
              {pairs.map(p => (
                <div key={p.name}>
                  <dt>{p.name}</dt>
                  <dd>{p.ratio.toFixed(1)} : 1</dd>
                </div>
              ))}
            </>
          ) : (
            <div><dt>Non-text</dt><dd>decorative only</dd></div>
          )}
        </dl>
      </footer>
    </article>
  );
}

// ---------- Primitive board ----------
function PrimitiveBoard(){
  return (
    <div className="board board--prim">
      <header className="board__head">
        <div className="board__eyebrow">
          <span className="board__dot" />
          <span>§ 3.2 — Primitive Palette</span>
        </div>
        <h2 className="board__title">Seven primitives.</h2>
        <p className="board__lede">
          A <em>primitive</em> is a raw, named hex value — the lowest layer
          of the token stack. Semantic tokens (brand, action, surface) and
          component tokens map onto these seven; nothing in production
          references a hex code directly. Change a primitive and the whole
          system shifts in lockstep.
        </p>
        <div className="board__meta">
          <span>Tokens · 7</span>
          <span>·</span>
          <span>Surfaces · Cream / Paper</span>
          <span>·</span>
          <span>Updated · v1.0</span>
        </div>
      </header>

      <div className="prim-grid">
        {PRIMITIVES.map((c, i) => <PrimitiveCard key={c.name} c={c} index={i} />)}
      </div>

      <footer className="board__foot">
        <span className="board__sig">Green Property Management Design System  |  Confidential</span>
        <span className="board__page">3.2 / 01</span>
      </footer>
    </div>
  );
}

// ---------- Derived neutral card ----------
function DerivedCard({ d, index }){
  const badgeKey =
    d.badge === "AAA"      ? "aaa" :
    d.badge === "AA"       ? "aa"  :
    d.badge === "AA·LG"    ? "lg"  : "non";
  return (
    <article className="der">
      <header className="der__head">
        <span className="der__index">D / {String(index + 1).padStart(2, '0')}</span>
        <span className={`der__badge der__badge--${badgeKey}`}>{d.badge}</span>
      </header>

      <div className="der__id">
        <span className="der__token">{d.token}</span>
        <span className="der__hex">{d.hex.toUpperCase()}</span>
      </div>

      <div className="der__specimen">
        <span className="der__specimen-label">Specimen · on Paper</span>
        {d.demo.kind === "text" ? (
          <>
            <p className="der__specimen-heading" style={{ color: d.hex }}>{d.demo.heading}</p>
            <p className="der__specimen-body"    style={{ color: d.hex }}>{d.demo.body}</p>
          </>
        ) : (
          <div className="der__divider-demo">
            <hr style={{ borderTop: `1px solid ${d.hex}` }} />
            <div className="der__divider-box" style={{ borderColor: d.hex }}>
              Bordered surface
            </div>
            <hr style={{ borderTop: `1px solid ${d.hex}` }} />
          </div>
        )}
      </div>

      <p className="der__role">{d.role}</p>

      <footer className="der__foot">
        <div className="der__ratio-bar" aria-hidden="true">
          <div
            className="der__ratio-fill"
            style={{ width: `${Math.min(d.ratio / 12, 1) * 100}%`, background: d.hex }}
          />
        </div>
        <div className="der__ratio-row">
          <span>Contrast on Paper</span>
          <span className="der__ratio-val">{d.ratio.toFixed(1)} : 1</span>
        </div>
      </footer>
    </article>
  );
}

// ---------- Derived board ----------
function DerivedBoard(){
  return (
    <div className="board board--der">
      <header className="board__head">
        <div className="board__eyebrow">
          <span className="board__dot" />
          <span>§ 3.3 — Derived Neutrals</span>
        </div>
        <h2 className="board__title">Four steps of Ink.</h2>
        <p className="board__lede">
          <em>Derived neutrals</em> are tints ramped from the Ink primitive,
          used as foreground text and UI hierarchy on Cream and Paper surfaces.
          They never act as backgrounds — each step is a typographic role:
          body emphasis, metadata, disabled, divider.
        </p>
        <div className="board__meta">
          <span>Tokens · 4</span>
          <span>·</span>
          <span>Base · Ink #1F2A2E</span>
          <span>·</span>
          <span>WCAG · 2.1 AA</span>
        </div>
      </header>

      <div className="der-grid">
        {DERIVED.map((d, i) => <DerivedCard key={d.token} d={d} index={i} />)}
      </div>

      <footer className="board__foot">
        <span className="board__sig">Green Property Management Design System  |  Confidential</span>
        <span className="board__page">3.3 / 02</span>
      </footer>
    </div>
  );
}

// ---------- Mount ----------
window.PrimitiveBoard = PrimitiveBoard;
window.DerivedBoard = DerivedBoard;
