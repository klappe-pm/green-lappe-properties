---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P1
aliases:
tags:
---

# customer-acquisition-cost-per-owner

## summary

Total sales and marketing spend divided by the number of new owner accounts won in a period.

## category

Financial Performance (P1 priority)

## what it signals

Efficiency of growth engine. Low CAC + strong organic = competitive moat. High CAC = paid-channel dependence.

## how to interpret

CAC alone is meaningless; always pair with LTV. Referral-driven CAC is structurally lower and more defensible than paid-search CAC. Track trend, not just level.

## benchmark

$500 to $2,500 per new owner typical for SFR PM in PNW.

## example

Firm spends $40K/yr on Google Ads and SEO content, wins 32 new owners. CAC = $1,250. Another firm wins 50 owners on $15K (mostly referrals + NARPM). CAC = $300.

## paired metrics

Evaluate this metric alongside:

- [[ltv-per-owner|LTV per Owner]]
- [[ltv-to-cac-ratio|LTV to CAC Ratio]]
- [[payback-period|Payback Period]]
- [[marketing-channels-active|Marketing Channels Active]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-churn-rate|Owner Churn Rate (high CAC + high churn = death spiral)]]

## source / how to measure

Marketing spend + new logo count from internal reporting.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
