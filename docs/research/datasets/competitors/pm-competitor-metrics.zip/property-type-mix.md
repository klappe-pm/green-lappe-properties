---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P1
aliases:
tags:
---

# property-type-mix

## summary

Percent split across SFR, condo, townhome, small multifamily, large multifamily, commercial, HOA.

## category

Portfolio Composition (P1 priority)

## what it signals

Operating model. SFR + small multifamily = different unit economics, vendor needs, and compliance posture than large multifamily.

## how to interpret

Mixed portfolios diffuse focus. Specialists usually outperform on the operational metrics within their type.

## benchmark

SFR + small MF dominant for small-landlord ICP.

## example

70% SFR, 20% condo/townhome, 10% small MF.

## paired metrics

Evaluate this metric alongside:

- [[stated-icp|Stated ICP]]
- [[average-rent-per-unit|Average Rent per Unit]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Firm portfolio; MLS rental listings.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
