---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P1
aliases:
tags:
---

# average-doors-per-owner

## summary

Mean number of managed units per owner client.

## category

Portfolio Composition (P1 priority)

## what it signals

Customer profile. Below 3 = mom-and-pop focus. 5+ = mid-tier investor focus. 20+ = institutional or syndicate exposure.

## how to interpret

Matters most when measuring competitive fit. A new entrant targeting small landlords should benchmark against firms in the 1-5 range.

## benchmark

1-5 for small-landlord ICP.

## example

1,000 units / 400 owners = 2.5 doors per owner; mom-and-pop ICP.

## paired metrics

Evaluate this metric alongside:

- [[owner-concentration|Owner Concentration]]
- [[stated-icp|Stated ICP]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Owner roster.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
