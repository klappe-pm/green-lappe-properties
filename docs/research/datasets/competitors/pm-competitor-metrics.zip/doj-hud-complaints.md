---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P0
aliases:
tags:
---

# doj-hud-complaints

## summary

Department of Justice or HUD fair housing or civil rights complaints.

## category

Compliance and Risk (P0 priority)

## what it signals

Severe regulatory exposure.

## how to interpret

Zero is the only acceptable target.

## benchmark

0.

## example

Any open or recent DOJ/HUD complaint is a disqualifying event for serious owners.

## paired metrics

Evaluate this metric alongside:

- [[ag-complaints|AG Complaints]]
- [[fair-housing-training-cadence|Fair Housing Training Cadence]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

DOJ and HUD public databases.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
