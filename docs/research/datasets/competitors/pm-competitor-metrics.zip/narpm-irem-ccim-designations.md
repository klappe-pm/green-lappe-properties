---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P1
aliases:
tags:
---

# narpm-irem-ccim-designations

## summary

Specific staff-held designations from NARPM, IREM, and CCIM.

## category

Team and Capacity (P1 priority)

## what it signals

Individual operator capability and continuing education investment.

## how to interpret

MPM and CPM are individual top-tier. Indicates investment in staff development.

## benchmark

1+ MPM or CPM for firms above 500 units.

## example

2 staff with MPM (NARPM Master), 1 with CPM (IREM).

## paired metrics

Evaluate this metric alongside:

- [[designations-held|Designations Held]]
- [[associations|Associations]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

NARPM and IREM directories.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
