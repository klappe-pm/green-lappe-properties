---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# eviction-rate-per-100-units

## summary

Number of unlawful detainer cases filed annually per 100 units under management.

## category

Operational Performance (P1 priority)

## what it signals

Screening rigor and rent collection discipline. Also reflects portfolio quality (Class C tends to higher).

## how to interpret

Above 2 per 100 SFR units annually indicates screening or portfolio class issue. Zero with high delinquency means non-enforcement.

## benchmark

<1 per 100 healthy SFR.

## example

1,000 units, 4 evictions filed in 12 months = 0.4 per 100 units.

## paired metrics

Evaluate this metric alongside:

- [[credit-score-min|Credit Score Min]]
- [[income-to-rent-ratio|Income-to-Rent Ratio]]
- [[delinquency-rate|Delinquency Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[vacancy-rate|Vacancy Rate (low evictions and low vacancy together is strong signal)]]

## source / how to measure

King and Snohomish County District Court records, public.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
