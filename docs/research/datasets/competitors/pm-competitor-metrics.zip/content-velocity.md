---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: strategic-positioning
priority-tier: P2
aliases:
tags:
---

# content-velocity

## summary

Volume of blog, video, podcast, or social content published per quarter.

## category

Strategic Positioning (P2 priority)

## what it signals

Inbound marketing investment.

## how to interpret

1+ post per month is healthy. Dormant content is a yellow flag on marketing investment.

## benchmark

1+ per month.

## example

2 blog posts/month + monthly podcast + weekly LinkedIn. Or: dormant blog last updated 2022.

## paired metrics

Evaluate this metric alongside:

- [[domain-authority|Domain Authority]]
- [[seo-rank-for-city-plus-pm|SEO Rank for City Plus PM]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website blog; podcast directories.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
