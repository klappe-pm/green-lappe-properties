---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: strategic-positioning
priority-tier: P1
aliases:
tags:
---

# marketing-channels-active

## summary

Active acquisition channels: SEO, SEM, referral programs, NARPM, partnerships, content.

## category

Strategic Positioning (P1 priority)

## what it signals

Customer acquisition strategy maturity.

## how to interpret

Diversified channels = lower risk and lower blended CAC. Single-channel dependence is fragile.

## benchmark

3+ active channels.

## example

SEO + Google Ads + NARPM + agent referral program + content blog. Or: Google Ads only.

## paired metrics

Evaluate this metric alongside:

- [[cac-per-owner|CAC per Owner]]
- [[domain-authority|Domain Authority]]
- [[owner-referral-rate|Owner Referral Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website, ad library, owner interviews.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
