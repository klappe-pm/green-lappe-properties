---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P1
aliases:
tags:
---

# revenue-mix

## summary

Percentage breakdown of revenue across management fees, leasing fees, ancillary, and maintenance markup.

## category

Financial Performance (P1 priority)

## what it signals

How balanced the firm's economics are. Over-reliance on any one bucket is fragile.

## how to interpret

Management fee revenue should dominate. High leasing share means high turnover (bad for owner). High ancillary or maintenance markup means hidden pricing.

## benchmark

Mgmt 60-75%; Leasing 15-25%; Ancillary 5-15%; Maintenance markup <5%.

## example

Healthy: 70% mgmt fees, 18% leasing, 10% ancillary, 2% maintenance markup. Skewed: 45% mgmt, 20% leasing, 25% ancillary, 10% maintenance markup (high markup signals opacity).

## paired metrics

Evaluate this metric alongside:

- [[average-management-fee-realized|Average Management Fee Realized]]
- [[ancillary-revenue-per-unit|Ancillary Revenue per Unit]]
- [[maintenance-markup-transparency|Maintenance Markup Transparency]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-nps|Owner NPS]]

## source / how to measure

Owner statement audit; P&L if disclosed.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
