---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P2
aliases:
tags:
---

# affiliate-network

## summary

Network of insurance, lending, title, and vendor partners.

## category

Growth and Corporate Development (P2 priority)

## what it signals

Ancillary revenue and owner stickiness.

## how to interpret

Robust affiliate network deepens owner relationship without intrusive cross-sell.

## benchmark

3+ active affiliate relationships.

## example

Preferred insurance broker, lender, 1031 facilitator, vendor stack with discounts for owners.

## paired metrics

Evaluate this metric alongside:

- [[marketing-channels-active|Marketing Channels Active]]
- [[ancillary-revenue-per-unit|Ancillary Revenue per Unit]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website partners page; owner interviews.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
