---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P2
aliases:
tags:
---

# investor-relationships

## summary

Whether the firm manages a portfolio for related investors, including the firm principals.

## category

Growth and Corporate Development (P2 priority)

## what it signals

Conflict-of-interest exposure and capital access.

## how to interpret

Internal portfolio is fine if disclosed and managed with same priority as third-party. Hidden internal portfolio is grounds for owner attrition.

## benchmark

Disclosed.

## example

Manages own portfolio (15% of units) in addition to third-party. Or: zero house portfolio.

## paired metrics

Evaluate this metric alongside:

- [[owns-portfolio|Owns Portfolio]]
- [[brokerage-tie-in|Brokerage Tie-In]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Firm disclosure; broker filings.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
