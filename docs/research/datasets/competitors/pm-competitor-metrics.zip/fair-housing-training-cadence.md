---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P1
aliases:
tags:
---

# fair-housing-training-cadence

## summary

Frequency of Fair Housing training for staff, especially leasing agents and property managers.

## category

Compliance and Risk (P1 priority)

## what it signals

Discrimination litigation defense and process discipline.

## how to interpret

Annual minimum is expected; documented training records are the audit defense.

## benchmark

Annual minimum.

## example

Annual mandatory + new-hire onboarding + bi-annual refresher.

## paired metrics

Evaluate this metric alongside:

- [[doj-hud-complaints|DOJ HUD Complaints]]
- [[seattle-compliance-posture|Seattle Compliance Posture]]
- [[ag-complaints|AG Complaints]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Firm self-report; HR records during diligence.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
