---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: technology-and-process-maturity
priority-tier: P1
aliases:
tags:
---

# self-showing-technology

## summary

Unattended-showing platform (Showdigs, Tenant Turner, Rently, ShowMojo).

## category

Technology and Process Maturity (P1 priority)

## what it signals

Leasing speed and modern ops.

## how to interpret

Strong adoption is a competitive moat in PNW PM. Cuts days on market by a measurable margin.

## benchmark

Adoption among top quartile.

## example

Showdigs handling 60% of showings; in-person reserved for finalists.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[time-to-first-showing|Time to First Showing]]
- [[showings-per-vacancy|Showings per Vacancy]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[application-to-lease-conversion|Application-to-Lease Conversion (self-showings can lower quality of pipeline)]]

## source / how to measure

Listing screenshots; tour booking flow.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
