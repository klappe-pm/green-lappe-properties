---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P2
aliases:
tags:
---

# bbb-complaint-count

## summary

Number of BBB complaints filed, not just the letter grade.

## category

Reputation and Customer Experience (P2 priority)

## what it signals

Sentiment volume. Letter grade often hides complaint volume.

## how to interpret

Always pair complaint count with resolution rate. The letter grade alone is a weak signal.

## benchmark

<5 over 3 years for sub-1000-unit firm.

## example

A+ rating with 24 complaints over 3 years vs A+ with 4 complaints.

## paired metrics

Evaluate this metric alongside:

- [[bbb-complaint-resolution-rate|BBB Complaint Resolution Rate]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

BBB profile.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
