---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: strategic-positioning
priority-tier: P1
aliases:
tags:
---

# differentiation-claim

## summary

The stated competitive positioning vs the rest of the market.

## category

Strategic Positioning (P1 priority)

## what it signals

How the firm believes it competes.

## how to interpret

Specific claims (transparent pricing, in-house maintenance, fast turn) are competitive. Generic trust language is marketing fluff.

## benchmark

Specific > generic.

## example

'Transparent flat pricing with no maintenance markup' vs 'full-service property management you can trust' (generic).

## paired metrics

Evaluate this metric alongside:

- [[stated-icp|Stated ICP]]
- [[pricing-transparency|Pricing Transparency]]
- [[performance-guarantees|Performance Guarantees]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website homepage.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
