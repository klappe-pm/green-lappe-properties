---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P1
aliases:
tags:
---

# owner-referral-rate

## summary

Percent of new owners that come via referral from existing owners.

## category

Reputation and Customer Experience (P1 priority)

## what it signals

Trust and advocacy quality. Cleanest signal of true satisfaction.

## how to interpret

Above 30% is healthy. Above 50% means the firm has a structural acquisition advantage.

## benchmark

30%+ healthy.

## example

32 new owners YTD, 14 via referral = 44%.

## paired metrics

Evaluate this metric alongside:

- [[owner-nps|Owner NPS]]
- [[cac-per-owner|CAC per Owner]]
- [[repeat-owner-rate|Repeat-Owner Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Internal CRM.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
