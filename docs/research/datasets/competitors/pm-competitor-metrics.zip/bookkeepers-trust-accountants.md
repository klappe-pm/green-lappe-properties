---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P2
aliases:
tags:
---

# bookkeepers-trust-accountants

## summary

Number of accounting and trust function staff.

## category

Team and Capacity (P2 priority)

## what it signals

Compliance and reporting capacity.

## how to interpret

1 per 300-500 units is healthy. Below that creates compliance risk.

## benchmark

1 per 300-500 units.

## example

2 trust accountants for 1,000 units.

## paired metrics

Evaluate this metric alongside:

- [[trust-accounting-practices|Trust Accounting Practices]]
- [[trust-account-audit-history|Trust Account Audit History]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

LinkedIn employee search.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
