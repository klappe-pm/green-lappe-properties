---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P0
aliases:
tags:
---

# maintenance-markup-transparency

## summary

Whether the firm marks up vendor invoices before passing to owner, and whether the markup is disclosed.

## category

Service and Pricing Depth (P0 priority)

## what it signals

Pricing ethics. Hidden markup is the most common owner trust failure mode.

## how to interpret

Disclosed 0-10% is acceptable. Undisclosed markup is grounds for owner attrition once discovered.

## benchmark

0% (no markup) is competitive moat.

## example

Firm A: 0% markup, vendor invoices passed at cost. Firm B: 10% disclosed coordination fee. Firm C: invoice marked up 15-20% with no disclosure.

## paired metrics

Evaluate this metric alongside:

- [[ancillary-revenue-per-unit|Ancillary Revenue per Unit]]
- [[pricing-transparency|Pricing Transparency]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[maintenance-cost-per-unit|Maintenance Cost per Unit]]

## source / how to measure

Sample owner statement vs vendor invoice spot check.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
