---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P2
aliases:
tags:
---

# facebook-rating-and-count

## summary

Facebook recommendation score and number of recommendations.

## category

Reputation and Customer Experience (P2 priority)

## what it signals

Owner-side sentiment (Facebook skews toward owner reviews vs Yelp toward tenants).

## how to interpret

Lower-volume but owner-skewing platform. Triangulate with Google and Yelp.

## benchmark

4.0+ healthy if present.

## example

4.6 stars across 38 reviews vs no Facebook presence.

## paired metrics

Evaluate this metric alongside:

- [[owner-nps|Owner NPS]]
- [[repeat-owner-rate|Repeat-Owner Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Facebook page.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
