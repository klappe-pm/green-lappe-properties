---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# application-to-lease-conversion-rate

## summary

Percentage of submitted rental applications that result in a signed lease.

## category

Operational Performance (P1 priority)

## what it signals

Pricing accuracy and screening rigor. Low conversion = mispricing, slow process, or overly tight screening.

## how to interpret

Below 50% indicates pricing or process friction. Above 90% may indicate insufficient screening.

## benchmark

60-80% healthy.

## example

30 applications, 22 leases signed = 73% conversion.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[showings-per-vacancy|Showings per Vacancy]]
- [[application-fee|Application Fee]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[eviction-rate-per-100-units|Eviction Rate per 100 Units (loose screening + high conversion shows up later as evictions)]]

## source / how to measure

PMS application report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
