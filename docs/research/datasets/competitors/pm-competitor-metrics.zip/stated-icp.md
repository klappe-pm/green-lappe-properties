---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: strategic-positioning
priority-tier: P1
aliases:
tags:
---

# stated-icp

## summary

The firm's stated ideal customer profile.

## category

Strategic Positioning (P1 priority)

## what it signals

Strategic clarity and competitive fit.

## how to interpret

Specific ICP indicates strategic discipline. Generic positioning suggests the firm takes whatever business walks in.

## benchmark

Specific > generic.

## example

'Single-family rental investors with 1-5 properties in King County' vs 'all kinds of landlords welcome'.

## paired metrics

Evaluate this metric alongside:

- [[average-doors-per-owner|Average Doors per Owner]]
- [[property-type-mix|Property Type Mix]]
- [[differentiation-claim|Differentiation Claim]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website homepage and about page.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
