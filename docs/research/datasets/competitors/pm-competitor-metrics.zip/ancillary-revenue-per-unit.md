---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P0
aliases:
tags:
---

# ancillary-revenue-per-unit

## summary

Annual non-management-fee revenue per managed unit, including pet fees, late fees, lease prep charges, NSF fees, eviction processing, and similar line items.

## category

Financial Performance (P0 priority)

## what it signals

Whether the firm earns its margin transparently from management fees or quietly from owner-and-tenant nickel-and-diming. High ancillary at otherwise low management fees often means hidden cost structure.

## how to interpret

Compare the advertised management fee to the ancillary load. Healthy operators land at $150 to $400 per unit per year. Above $500 with low transparency is a red flag; that firm is selling a discount headline and earning back margin in fine print.

## benchmark

$150 to $400 per unit per year typical SFR; >$500 warrants pricing audit.

## example

Firm A advertises 8% management fee. Statement audit shows $420/unit/yr in ancillaries (lease prep $200, late fees $90, pet fees $130). Realized take is closer to 11% of gross rent. Firm B advertises 10% with $80/unit/yr ancillary; cleaner economics for the owner.

## paired metrics

Evaluate this metric alongside:

- [[gross-revenue-per-unit|Gross Revenue per Unit]]
- [[maintenance-markup-transparency|Maintenance Markup Transparency]]
- [[pricing-transparency|Pricing Transparency]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-nps|Owner NPS (high ancillary often drags NPS down)]]
- [[owner-churn-rate|Owner Churn Rate (hidden fees correlate with churn spikes)]]

## source / how to measure

Owner statement sample audit; PMS revenue breakdown; quarterly P&L reviews.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
