---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# lease-compliance-incidents

## summary

Number of legal exposure incidents per year (violations of local ordinance, fair housing complaints, security deposit disputes, late notices not properly served).

## category

Operational Performance (P1 priority)

## what it signals

Process discipline and regulatory awareness, critical given Seattle's dense ordinance stack.

## how to interpret

Even resolved incidents indicate process gaps. Zero incidents at scale is the signal of a mature firm.

## benchmark

<3 per 1,000 units annually.

## example

Three security deposit return disputes filed, one Fair Chance complaint dismissed, two improper rent increase notices flagged.

## paired metrics

Evaluate this metric alongside:

- [[ag-complaints|AG Complaints]]
- [[litigation-history|Litigation History]]
- [[fair-housing-training-cadence|Fair Housing Training Cadence]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[net-unit-growth|Net Unit Growth (growth without process maturity often creates compliance gaps)]]

## source / how to measure

Firm self-report; court records; AG public records.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
