---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P1
aliases:
tags:
---

# total-headcount

## summary

Full-time equivalents at the firm.

## category

Team and Capacity (P1 priority)

## what it signals

Operational capacity.

## how to interpret

Track revenue per FTE as the productivity metric. PNW PM benchmarks $150K-$250K revenue/FTE.

## benchmark

Varies with portfolio size and tech leverage.

## example

18 FTE for 1,000-unit portfolio.

## paired metrics

Evaluate this metric alongside:

- [[doors-per-property-manager|Doors per Property Manager]]
- [[portfolio-size|Portfolio Size]]
- [[total-revenue-per-fte|Total Revenue per FTE]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

LinkedIn, Glassdoor.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
