---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: strategic-positioning
priority-tier: P2
aliases:
tags:
---

# domain-authority

## summary

Moz or Ahrefs domain authority score (0-100).

## category

Strategic Positioning (P2 priority)

## what it signals

Organic acquisition capability.

## how to interpret

DA 30+ is competitive in PNW PM. Higher DA means cheaper organic acquisition.

## benchmark

30+ competitive.

## example

Moz DA 35 vs DA 12.

## paired metrics

Evaluate this metric alongside:

- [[seo-rank-for-city-plus-pm|SEO Rank for City Plus PM]]
- [[content-velocity|Content Velocity]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Moz, Ahrefs.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
