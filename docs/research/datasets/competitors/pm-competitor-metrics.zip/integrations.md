---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: technology-and-process-maturity
priority-tier: P2
aliases:
tags:
---

# integrations

## summary

Active integrations with accounting (QuickBooks), screening (TransUnion, Experian), insurance, utilities, smart locks.

## category

Technology and Process Maturity (P2 priority)

## what it signals

Stack maturity and data flow automation.

## how to interpret

Heavy integrations cut manual reconciliation and reduce error rate.

## benchmark

5+ active integrations for top quartile.

## example

AppFolio + QuickBooks Online + RentTrack + Latchkey + Conservice utilities.

## paired metrics

Evaluate this metric alongside:

- [[core-pms|Core PMS]]
- [[owner-portal-features-depth|Owner Portal Features Depth]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Firm self-report; vendor partner pages.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
