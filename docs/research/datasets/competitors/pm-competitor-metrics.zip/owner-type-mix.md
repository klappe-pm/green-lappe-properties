---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P2
aliases:
tags:
---

# owner-type-mix

## summary

Share of owners by category: mom-and-pop (1-3 doors), mid-tier (4-20), institutional (20+).

## category

Portfolio Composition (P2 priority)

## what it signals

Pricing power and service expectations differ sharply by tier.

## how to interpret

Mom-and-pop = highest service expectations relative to fee paid. Institutional = lowest fee but lowest service complexity per unit.

## benchmark

ICP-dependent.

## example

60% mom-and-pop, 35% mid-tier, 5% institutional.

## paired metrics

Evaluate this metric alongside:

- [[stated-icp|Stated ICP]]
- [[average-doors-per-owner|Average Doors per Owner]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Owner roster classification.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
