---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P2
aliases:
tags:
---

# inspection-cadence

## summary

Frequency of formal property inspections (move-in, move-out, periodic, drive-by).

## category

Operational Performance (P2 priority)

## what it signals

Asset protection commitment.

## how to interpret

Move-in/out plus annual is the minimum for asset protection. Quarterly drive-by adds risk coverage.

## benchmark

Move-in/out + annual interior minimum.

## example

Firm A: move-in, move-out, annual interior, semi-annual drive-by. Firm B: move-in and move-out only.

## paired metrics

Evaluate this metric alongside:

- [[maintenance-cost-per-unit|Maintenance Cost per Unit]]
- [[security-deposit-disputes|Security Deposit Disputes]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-nps|Owner NPS (over-inspection irritates owners; under-inspection irritates them later)]]

## source / how to measure

Management agreement.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
