---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# emergency-response-time

## summary

Time from emergency maintenance request submission to first dispatched response.

## category

Operational Performance (P1 priority)

## what it signals

Tenant safety and liability exposure.

## how to interpret

Over 4 hours for water, fire, or no-heat conditions creates serious liability exposure.

## benchmark

<2 hours expected.

## example

Burst pipe reported 11pm, plumber dispatched 11:38pm = 38 minutes.

## paired metrics

Evaluate this metric alongside:

- [[maintenance-cycle-time|Maintenance Cycle Time]]
- [[first-time-fix-rate|First-Time Fix Rate]]
- [[communication-sla|Communication SLA]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[maintenance-cost-per-unit|Maintenance Cost per Unit (always-available 24/7 dispatch costs more)]]

## source / how to measure

PMS work order timestamps.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
