---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P0
aliases:
tags:
---

# doors-per-property-manager

## summary

Total managed units divided by the number of property managers.

## category

Team and Capacity (P0 priority)

## what it signals

Workload, service quality, and the firm's tech leverage. Industry healthy band is 150-350 SFR depending on tech.

## how to interpret

Below 150 is high-touch (or under-leveraged tech). Above 350 SFR signals degraded service. Above 500 is unsustainable without strong automation.

## benchmark

150-250 SFR; up to 350 with strong tech.

## example

1,000 units / 4 PMs = 250 doors/PM. 1,000 units / 2 PMs = 500 doors/PM.

## paired metrics

Evaluate this metric alongside:

- [[total-headcount|Total Headcount]]
- [[maintenance-cycle-time|Maintenance Cycle Time]]
- [[owner-nps|Owner NPS]]
- [[tenant-nps|Tenant NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Calculated from LinkedIn + portfolio size.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
