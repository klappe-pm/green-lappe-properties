---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P1
aliases:
tags:
---

# owner-concentration

## summary

Percent of total revenue or units owned by the top 10 owners.

## category

Portfolio Composition (P1 priority)

## what it signals

Key-customer risk. High concentration = single loss event can crater revenue.

## how to interpret

Anything over 30% in the top 10 is concentration risk. Over 50% means the firm essentially serves one investor.

## benchmark

<30% healthy.

## example

Top 10 owners control 38% of units. One owner (250 units) = 25% of revenue.

## paired metrics

Evaluate this metric alongside:

- [[average-doors-per-owner|Average Doors per Owner]]
- [[net-unit-growth-rate|Net Unit Growth Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Owner roster (rarely public; estimated from listing patterns).

## see also

- [[pm-competitor-metrics-index|metric catalog]]
