---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P0
aliases:
tags:
---

# google-review-count

## summary

Total Google Business Profile reviews.

## category

Reputation and Customer Experience (P0 priority)

## what it signals

Public sentiment scale. Most important review platform.

## how to interpret

Count below 30 means low statistical confidence. Above 100 means meaningful sentiment signal.

## benchmark

>50 reviews.

## example

284 reviews at 4.3 average vs 11 reviews at 4.8.

## paired metrics

Evaluate this metric alongside:

- [[google-rating|Google Rating]]
- [[review-velocity|Review Velocity]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Google Maps.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
