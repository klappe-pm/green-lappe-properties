---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P0
aliases:
tags:
---

# yelp-review-count

## summary

Total Yelp reviews.

## category

Reputation and Customer Experience (P0 priority)

## what it signals

Tenant-skewing sentiment volume.

## how to interpret

Yelp structurally runs lower for PM. Read content, not just stars.

## benchmark

>30 reviews.

## example

179 Yelp reviews 3.2 avg vs 37 reviews 3.8 avg.

## paired metrics

Evaluate this metric alongside:

- [[yelp-rating|Yelp Rating]]
- [[tenant-nps|Tenant NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[google-review-count|Google Review Count (Yelp skews more negative for PM)]]

## source / how to measure

Yelp.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
