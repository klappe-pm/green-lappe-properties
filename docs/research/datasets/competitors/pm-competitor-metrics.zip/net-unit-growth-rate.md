---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P0
aliases:
tags:
---

# net-unit-growth-rate

## summary

Units added minus units lost over trailing 12 months, divided by starting unit count.

## category

Financial Performance (P0 priority)

## what it signals

The cleanest single indicator of firm health. Captures the net of owner wins and losses.

## how to interpret

Positive single-digit growth is healthy for a mature firm. Double-digit growth without proportional hiring should be questioned. Net negative growth is a serious red flag for a firm not in deliberate portfolio rationalization.

## benchmark

+5% annual healthy; -10% indicates distress.

## example

1,000 → 1,080 units = +8% growth. 1,000 → 920 = -8%, distress signal.

## paired metrics

Evaluate this metric alongside:

- [[owner-churn-rate|Owner Churn Rate]]
- [[cac-per-owner|CAC per Owner]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[doors-per-property-manager|Doors per Property Manager (growth without hiring degrades service quality)]]

## source / how to measure

Listing churn proxy; owner interviews; LinkedIn hiring posts.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
