---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P2
aliases:
tags:
---

# tax-reporting-included

## summary

Whether 1099-MISC issuance and end-of-year tax reporting are included in management fee.

## category

Service and Pricing Depth (P2 priority)

## what it signals

Service completeness and accounting maturity.

## how to interpret

Should be bundled. Upcharging signals nickel-and-diming posture.

## benchmark

Bundled.

## example

Bundled with management fee vs $50/year upcharge.

## paired metrics

Evaluate this metric alongside:

- [[owner-reporting-cadence|Owner Reporting Cadence]]
- [[trust-accounting-practices|Trust Accounting Practices]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Management agreement.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
