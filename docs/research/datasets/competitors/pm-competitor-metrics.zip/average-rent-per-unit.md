---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P2
aliases:
tags:
---

# average-rent-per-unit

## summary

Mean monthly rent across the managed portfolio.

## category

Portfolio Composition (P2 priority)

## what it signals

Submarket positioning and class mix.

## how to interpret

Above market median = Class A or premium positioning. Below = Class B/C focus.

## benchmark

Seattle SFR median ~$2,800 as of 2025.

## example

Portfolio average $2,650/mo.

## paired metrics

Evaluate this metric alongside:

- [[class-a-b-c-mix|Class A B C Mix]]
- [[property-type-mix|Property Type Mix]]
- [[gross-revenue-per-unit|Gross Revenue per Unit]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Rentometer; firm-reported averages.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
