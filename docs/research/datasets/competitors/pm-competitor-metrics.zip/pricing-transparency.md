---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P0
aliases:
tags:
---

# pricing-transparency

## summary

Whether all fees are published on the website vs quote-only or buried in the agreement.

## category

Service and Pricing Depth (P0 priority)

## what it signals

Owner trust posture and the firm's confidence in its pricing.

## how to interpret

Published pricing is rare in PM and a meaningful competitive position when paired with reasonable fees.

## benchmark

Published, all-in.

## example

Firm A: full pricing table on site (mgmt %, leasing, renewal, setup, maintenance markup). Firm B: 'Call for pricing'.

## paired metrics

Evaluate this metric alongside:

- [[average-management-fee-realized|Average Management Fee Realized]]
- [[ancillary-revenue-per-unit|Ancillary Revenue per Unit]]
- [[contract-terms|Contract Terms]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website inspection.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
