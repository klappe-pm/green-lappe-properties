---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P1
aliases:
tags:
---

# payback-period-on-new-owner

## summary

Number of months for the gross profit from one new owner to cover the acquisition cost.

## category

Financial Performance (P1 priority)

## what it signals

Cash-flow constraint on growth. Long payback means growth requires capital.

## how to interpret

Under 12 months means growth pays for itself. Over 24 months means growth must be financed.

## benchmark

<12 months healthy; <18 acceptable; >24 problematic.

## example

CAC $1,500, monthly gross profit per owner $130. Payback = 11.5 months.

## paired metrics

Evaluate this metric alongside:

- [[cac-per-owner|CAC per Owner]]
- [[ltv-per-owner|LTV per Owner]]
- [[avg-doors-per-owner|Avg Doors per Owner]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-churn-rate|Owner Churn Rate (churn shorter than payback = losing money)]]

## source / how to measure

Calculated.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
