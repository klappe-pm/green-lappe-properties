---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P0
aliases:
tags:
---

# contract-terms

## summary

Cancellation notice required, exclusivity clauses, lockup terms, holdover claims, termination fees.

## category

Service and Pricing Depth (P0 priority)

## what it signals

Owner-friendliness and ethical posture. Hidden lockup clauses are a major retention crutch for weak operators.

## how to interpret

30-60 day no-fee is best practice. Anything longer or with lockup language warrants a competitive flag.

## benchmark

30-60 day no-fee termination.

## example

Firm A: 30-day notice, no fee, no lockup. Firm B: 90-day notice + $500 termination fee + commission lockup if owner sells within 180 days.

## paired metrics

Evaluate this metric alongside:

- [[pricing-transparency|Pricing Transparency]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-churn-rate|Owner Churn Rate (restrictive contracts suppress voluntary churn artificially)]]

## source / how to measure

Sample management agreement.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
