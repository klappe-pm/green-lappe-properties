---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P0
aliases:
tags:
---

# designated-broker-license-and-tenure

## summary

The named designated broker on the WA DOL firm license, and that broker's tenure.

## category

Compliance and Risk (P0 priority)

## what it signals

Liability anchor under RCW 18.85. A new or recently changed DB is a yellow flag.

## how to interpret

Tenure of 5+ years signals stability. Recent change warrants asking why.

## benchmark

5+ years tenure.

## example

Designated broker with 18 years at firm vs designated broker changed twice in 2 years.

## paired metrics

Evaluate this metric alongside:

- [[wa-dol-firm-license-status|WA DOL Firm License Status]]
- [[leadership-tenure|Leadership Tenure]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

dol.wa.gov firm search.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
