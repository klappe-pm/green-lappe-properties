---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P1
aliases:
tags:
---

# repeat-owner-rate

## summary

Percent of owners with 2 or more managed properties at the firm.

## category

Reputation and Customer Experience (P1 priority)

## what it signals

Trust depth. Owners only place a second property with firms they trust.

## how to interpret

Above 30% is healthy. Above 50% is a strong moat.

## benchmark

30%+ healthy.

## example

320 owners, 145 with 2+ properties = 45%.

## paired metrics

Evaluate this metric alongside:

- [[owner-nps|Owner NPS]]
- [[owner-referral-rate|Owner Referral Rate]]
- [[average-doors-per-owner|Average Doors per Owner]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Owner roster.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
