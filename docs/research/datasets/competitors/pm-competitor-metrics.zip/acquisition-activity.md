---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P2
aliases:
tags:
---

# acquisition-activity

## summary

Roll-up activity in the trailing 5 years (firms acquired or merged).

## category

Growth and Corporate Development (P2 priority)

## what it signals

M&A vs organic growth pattern; consolidation risk.

## how to interpret

Roll-up activity may signal PE behavior at scale. For independents, 1-2 small tuck-ins are normal.

## benchmark

0-3 typical for independent.

## example

Acquired 2 small firms in 3 years (added ~400 units). Or: 100% organic growth.

## paired metrics

Evaluate this metric alongside:

- [[net-unit-growth-rate|Net Unit Growth Rate]]
- [[ownership-type|Ownership Type]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Press releases, news, LinkedIn.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
