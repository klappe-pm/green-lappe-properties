---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P0
aliases:
tags:
---

# wa-dol-firm-license-status

## summary

Active Washington Department of Licensing firm real estate license.

## category

Compliance and Risk (P0 priority)

## what it signals

Required to operate. Absence is disqualifying.

## how to interpret

Always verify status directly via dol.wa.gov. Marketing claims of licensure mean nothing without verification.

## benchmark

Active required.

## example

Active firm license #XXXXX with current designated broker.

## paired metrics

Evaluate this metric alongside:

- [[designated-broker-license-and-tenure|Designated Broker License and Tenure]]
- [[trust-account-audit-history|Trust Account Audit History]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

dol.wa.gov firm search.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
