---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P2
aliases:
tags:
---

# gl-cyber-coverage

## summary

General liability and cyber liability insurance carrier and limits.

## category

Compliance and Risk (P2 priority)

## what it signals

Risk management maturity.

## how to interpret

Cyber liability is increasingly relevant given tenant PII held in PMS.

## benchmark

$1M GL + $1M cyber.

## example

$1M GL / $1M cyber with A-rated carrier.

## paired metrics

Evaluate this metric alongside:

- [[e-o-insurance-carrier-and-limits|E&O Insurance Carrier and Limits]]
- [[trust-accounting-practices|Trust Accounting Practices]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Insurance certificate.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
