---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P2
aliases:
tags:
---

# class-a-b-c-mix

## summary

Percent of portfolio by property class tier.

## category

Portfolio Composition (P2 priority)

## what it signals

Tenant default risk profile, maintenance load, eviction frequency, ancillary capture.

## how to interpret

Class C-heavy portfolios run higher maintenance, eviction, and turnover costs that must be priced into management fees.

## benchmark

B-class dominant for typical independent.

## example

20% Class A, 60% Class B, 20% Class C.

## paired metrics

Evaluate this metric alongside:

- [[average-rent-per-unit|Average Rent per Unit]]
- [[maintenance-cost-per-unit|Maintenance Cost per Unit]]
- [[eviction-rate-per-100-units|Eviction Rate per 100 Units]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Property age, rent vs market, neighborhood class.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
