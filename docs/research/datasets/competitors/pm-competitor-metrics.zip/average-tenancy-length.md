---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# average-tenancy-length

## summary

Mean tenant tenure across the portfolio, measured in months.

## category

Operational Performance (P1 priority)

## what it signals

Stability and turnover cost. Each turn costs the owner 1 to 2 months of rent plus make-ready expenses.

## how to interpret

Shorter than 18 months portfolio-wide signals systemic issues with screening, pricing, or property condition.

## benchmark

24-36 months healthy SFR.

## example

Portfolio mean 32 months. SFR averages 28-36 months in PNW.

## paired metrics

Evaluate this metric alongside:

- [[renewal-rate|Renewal Rate]]
- [[days-on-market|Days on Market]]
- [[vacancy-rate|Vacancy Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[rent-collection-rate|Rent Collection Rate (long tenancy can mask collections issues)]]

## source / how to measure

PMS tenancy report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
