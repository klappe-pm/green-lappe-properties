---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P2
aliases:
tags:
---

# review-velocity

## summary

New reviews in trailing 12 months vs prior 12 months across platforms.

## category

Reputation and Customer Experience (P2 priority)

## what it signals

Sentiment momentum. Declining velocity often precedes growth stalls.

## how to interpret

Track trend, not absolute. Sudden velocity drop with declining ratings is an alarm.

## benchmark

Stable or growing.

## example

TTM 38 new reviews vs prior 12 months 22 = 73% velocity increase.

## paired metrics

Evaluate this metric alongside:

- [[google-review-count|Google Review Count]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Manual count across platforms.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
