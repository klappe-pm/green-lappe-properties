---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P2
aliases:
tags:
---

# bbb-complaint-resolution-rate

## summary

Complaint count and resolution status (resolved vs unresolved) on the BBB profile.

## category

Compliance and Risk (P2 priority)

## what it signals

Customer service investment and dispute handling discipline.

## how to interpret

Resolution rate matters more than complaint count for established firms. Below 80% resolution is a yellow flag.

## benchmark

>90% resolution.

## example

12 complaints over 3 years, 11 resolved = 92% resolution.

## paired metrics

Evaluate this metric alongside:

- [[bbb-rating|BBB Rating]]
- [[owner-nps|Owner NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

BBB profile.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
