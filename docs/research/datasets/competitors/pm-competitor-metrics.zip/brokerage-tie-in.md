---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P2
aliases:
tags:
---

# brokerage-tie-in

## summary

Whether the firm operates a co-located sales brokerage.

## category

Growth and Corporate Development (P2 priority)

## what it signals

Cross-sell capability and conflict-of-interest exposure.

## how to interpret

Pure-play PM is a positioning advantage; owners know the firm is not just managing the property to sell it later.

## benchmark

Either model viable.

## example

Joint PM + brokerage operation. Or: pure-play PM with no sales brokerage.

## paired metrics

Evaluate this metric alongside:

- [[owns-portfolio|Owns Portfolio]]
- [[pricing-transparency|Pricing Transparency]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
