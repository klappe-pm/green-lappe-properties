---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P2
aliases:
tags:
---

# bilingual-staff-languages

## summary

Languages other than English spoken by staff with native or working fluency.

## category

Team and Capacity (P2 priority)

## what it signals

Tenant and owner pool reach in diverse markets.

## how to interpret

Mandarin and Spanish are particularly valuable in PNW. Korean and Vietnamese gaining relevance.

## benchmark

1-2 additional languages typical for top quartile.

## example

Mandarin, Cantonese, Spanish, Taiwanese.

## paired metrics

Evaluate this metric alongside:

- [[stated-icp|Stated ICP]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website team page.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
