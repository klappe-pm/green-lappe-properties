---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P0
aliases:
tags:
---

# owner-churn-rate

## summary

Percentage of owner accounts that terminate the management agreement annually. Often tracked as logo churn (count of owners) and unit churn (count of doors).

## category

Financial Performance (P0 priority)

## what it signals

Service quality, pricing fit, and competitive vulnerability. The leading indicator of long-term firm health.

## how to interpret

Always separate involuntary churn (owners sold their property) from voluntary churn (left for a competitor). The voluntary slice is the actionable signal.

## benchmark

<10% excellent; 10-20% typical; >25% distress.

## example

Firm starts year with 800 owners, ends with 720 retained = 10% churn. Firm with 25% churn that added 30% new owners shows net growth but is structurally unhealthy.

## paired metrics

Evaluate this metric alongside:

- [[owner-nps|Owner NPS]]
- [[net-unit-growth-rate|Net Unit Growth Rate]]
- [[renewal-rate|Renewal Rate]]
- [[repeat-owner-rate|Repeat-Owner Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[cac-per-owner|CAC per Owner (churn forces higher acquisition spend to stay flat)]]

## source / how to measure

Internal CRM; owner interviews; competitor poaching reports.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
