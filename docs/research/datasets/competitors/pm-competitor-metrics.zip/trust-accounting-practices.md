---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P0
aliases:
tags:
---

# trust-accounting-practices

## summary

Whether owner funds are held in separate trust accounts per owner vs commingled, in compliance with WA RCW 18.85.

## category

Service and Pricing Depth (P0 priority)

## what it signals

Compliance posture and audit readiness. The most common DOL revocation cause.

## how to interpret

Per-owner trust is the WA expectation. Pooled with weak reconciliation is a license risk.

## benchmark

Per-owner trust with monthly reconciliation.

## example

Per-owner trust accounts maintained, monthly reconciled. Or: pooled with manual sub-ledger.

## paired metrics

Evaluate this metric alongside:

- [[wa-dol-firm-license-status|WA DOL Firm License Status]]
- [[trust-account-audit-history|Trust Account Audit History]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

DOL audit records; firm self-report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
