---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P2
aliases:
tags:
---

# security-deposit-return-disputes

## summary

Number of formal disputes over security deposit returns annually.

## category

Compliance and Risk (P2 priority)

## what it signals

Move-out process discipline and documentation quality.

## how to interpret

Over 5% indicates documentation gap or aggressive deduction policy.

## benchmark

<3% of move-outs.

## example

8 disputes across 200 move-outs = 4% dispute rate.

## paired metrics

Evaluate this metric alongside:

- [[inspection-cadence|Inspection Cadence]]
- [[lease-compliance-incidents|Lease Compliance Incidents]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

King and Snohomish Small Claims records; tenant reviews.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
