---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: technology-and-process-maturity
priority-tier: P0
aliases:
tags:
---

# core-pms

## summary

Core property management software platform (AppFolio, Buildium, Rentvine, Rentec, Propertyware, Rent Manager, etc.).

## category

Technology and Process Maturity (P0 priority)

## what it signals

Tech stack ceiling. Determines available payment rails, reporting depth, owner/tenant portal quality, integration ecosystem.

## how to interpret

Platform choice constrains everything downstream. AppFolio is the local default and table stakes for serious competition.

## benchmark

AppFolio, Buildium, or Rentvine for credible competitor.

## example

AppFolio = mid-market modern. Buildium = small to mid. Rentec = budget. Spreadsheets = absence of platform.

## paired metrics

Evaluate this metric alongside:

- [[owner-portal-features-depth|Owner Portal Features Depth]]
- [[tenant-payment-methods|Tenant Payment Methods]]
- [[integrations|Integrations]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Tenant portal URL pattern, footer logos.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
