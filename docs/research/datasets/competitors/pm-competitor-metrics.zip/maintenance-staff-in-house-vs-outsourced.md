---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P1
aliases:
tags:
---

# maintenance-staff-in-house-vs-outsourced

## summary

Whether maintenance technicians are W-2 employees or all work is vendor-routed.

## category

Team and Capacity (P1 priority)

## what it signals

Cost control, SLA reliability, and quality consistency.

## how to interpret

In-house lowers markup, raises SLA reliability. Vendor-only is cheaper to scale but less controlled.

## benchmark

Mixed model typical.

## example

2 in-house techs handle handyman work; specialized trades go to vendors. Or: 100% vendor-routed.

## paired metrics

Evaluate this metric alongside:

- [[maintenance-cycle-time|Maintenance Cycle Time]]
- [[maintenance-cost-per-unit|Maintenance Cost per Unit]]
- [[maintenance-markup-transparency|Maintenance Markup Transparency]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website team; vendor interviews.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
