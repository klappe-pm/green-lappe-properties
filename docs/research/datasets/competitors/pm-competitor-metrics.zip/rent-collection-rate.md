---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P0
aliases:
tags:
---

# rent-collection-rate

## summary

Percent of rent collected on time (typically by the 5th of the month), with secondary cuts at day 10 and month-end.

## category

Operational Performance (P0 priority)

## what it signals

Cash flow predictability for owners. The metric owners care about most after vacancy.

## how to interpret

Below 90% on-time signals screening or process gap. The drop from on-time to month-end shows how much of the rent roll requires active collection.

## benchmark

92-97% on time healthy SFR.

## example

92% by the 5th, 97% by the 10th, 99% by month-end.

## paired metrics

Evaluate this metric alongside:

- [[delinquency-rate|Delinquency Rate]]
- [[credit-score-min|Credit Score Min]]
- [[income-to-rent-ratio|Income-to-Rent Ratio]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[eviction-rate-per-100-units|Eviction Rate per 100 Units]]

## source / how to measure

PMS collection report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
