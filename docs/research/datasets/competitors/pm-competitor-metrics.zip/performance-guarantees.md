---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P1
aliases:
tags:
---

# performance-guarantees

## summary

Service guarantees offered: tenant lease guarantee, pet damage guarantee, eviction protection, happiness guarantee, leasing speed guarantee.

## category

Service and Pricing Depth (P1 priority)

## what it signals

Risk-share posture and operational confidence.

## how to interpret

Two or more guarantees signal strong operations. Guarantees with low cap and many exclusions are marketing without substance.

## benchmark

2+ guarantees for top-quartile firms.

## example

Firm offers 30-day lease guarantee, $1,500 pet damage protection, and 60-day cancellation. Competitor offers none.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[eviction-rate-per-100-units|Eviction Rate per 100 Units]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website; management agreement.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
