---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P2
aliases:
tags:
---

# leasing-agent-count

## summary

Number of dedicated leasing staff.

## category

Team and Capacity (P2 priority)

## what it signals

Vacancy-fill capacity.

## how to interpret

Rough rule: 1 leasing agent per 30 vacancies per year. Specialization beats generalist PM showing.

## benchmark

1 per 30 annual vacancies.

## example

3 dedicated leasing agents for 800 doors.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[time-to-first-showing|Time to First Showing]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

LinkedIn.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
