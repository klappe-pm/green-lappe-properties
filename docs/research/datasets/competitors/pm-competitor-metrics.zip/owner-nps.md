---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P0
aliases:
tags:
---

# owner-nps

## summary

Net Promoter Score from owner survey.

## category

Reputation and Customer Experience (P0 priority)

## what it signals

Strongest churn predictor. Leading indicator of net unit growth.

## how to interpret

Above 30 is healthy for PM. Above 50 is exceptional. Below 0 means more detractors than promoters.

## benchmark

>30 healthy.

## example

Owner NPS 42 (top quartile) vs 8 (bottom quartile).

## paired metrics

Evaluate this metric alongside:

- [[owner-churn-rate|Owner Churn Rate]]
- [[repeat-owner-rate|Repeat-Owner Rate]]
- [[net-unit-growth-rate|Net Unit Growth Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Owner survey (rarely public; estimated via review sentiment analysis).

## see also

- [[pm-competitor-metrics-index|metric catalog]]
