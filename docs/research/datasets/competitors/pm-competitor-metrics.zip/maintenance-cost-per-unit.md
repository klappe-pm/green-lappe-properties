---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# maintenance-cost-per-unit

## summary

Total annual maintenance spend per managed unit, owner-billed.

## category

Operational Performance (P1 priority)

## what it signals

Portfolio age, vendor pricing, preventive maintenance discipline. High cost may indicate aging portfolio or vendor markup.

## how to interpret

Compare to portfolio age and rent. $1,500/yr at $2,400 average rent (62%) is normal. Same at $1,200 rent (150%) signals problem.

## benchmark

$1,000 to $2,500 typical SFR.

## example

$1,800 per unit per year average across SFR portfolio.

## paired metrics

Evaluate this metric alongside:

- [[maintenance-markup-transparency|Maintenance Markup Transparency]]
- [[average-rent-per-unit|Average Rent per Unit]]
- [[inspection-cadence|Inspection Cadence]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[tenant-nps|Tenant NPS (suppressing maintenance to look efficient hurts tenants)]]

## source / how to measure

Owner statements; PMS expense report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
