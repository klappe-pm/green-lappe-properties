---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P1
aliases:
tags:
---

# eviction-lawsuits-filed

## summary

Unlawful detainer cases filed by the firm in the trailing 12 months.

## category

Compliance and Risk (P1 priority)

## what it signals

Volume of forced collection. Public record so verifiable independently.

## how to interpret

Use absolute count to assess capacity and process maturity. Normalize per 100 units for cross-firm comparison.

## benchmark

Track over time; sharp increases are a signal.

## example

12 filings in TTM across 800 SFR units = 1.5 per 100 units.

## paired metrics

Evaluate this metric alongside:

- [[eviction-rate-per-100-units|Eviction Rate per 100 Units]]
- [[delinquency-rate|Delinquency Rate]]
- [[credit-score-min|Credit Score Min]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

King and Snohomish County District Court records.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
