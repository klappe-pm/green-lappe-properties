---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P2
aliases:
tags:
---

# showings-per-vacancy

## summary

Average number of showings conducted before a unit leases.

## category

Operational Performance (P2 priority)

## what it signals

Listing quality, pricing accuracy, marketing reach.

## how to interpret

Over 15 showings indicates listing or pricing problem. Under 4 means rent is below market.

## benchmark

6-12 showings per vacancy.

## example

Average 8 showings before lease signed.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[application-to-lease-conversion|Application-to-Lease Conversion]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Self-showing platform (Showdigs, Tenant Turner, Rently); leasing agent log.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
