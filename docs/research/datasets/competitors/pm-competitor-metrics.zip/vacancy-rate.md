---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P0
aliases:
tags:
---

# vacancy-rate

## summary

Percent of portfolio days vacant on a trailing 12-month basis.

## category

Operational Performance (P0 priority)

## what it signals

Combined leasing speed and turnover frequency. Compounds with Days on Market.

## how to interpret

Under 5% is healthy. Over 8% indicates leasing or pricing breakdown. Under 2% may mean rents are below market.

## benchmark

<5% healthy SFR.

## example

1,000 units × 365 days = 365,000 unit-days. 14,600 vacant = 4% vacancy.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[renewal-rate|Renewal Rate]]
- [[average-tenancy-length|Average Tenancy Length]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[rent-collection-rate|Rent Collection Rate]]

## source / how to measure

PMS occupancy report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
