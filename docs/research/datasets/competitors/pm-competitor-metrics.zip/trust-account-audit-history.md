---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P0
aliases:
tags:
---

# trust-account-audit-history

## summary

WA DOL trust account audit history and findings.

## category

Compliance and Risk (P0 priority)

## what it signals

License risk. Trust account issues are the highest-frequency cause of WA broker license revocation.

## how to interpret

Clean is the only acceptable position. Prior findings (even resolved) warrant scrutiny.

## benchmark

Clean.

## example

Clean audit history vs prior finding of commingling resolved with corrective action plan.

## paired metrics

Evaluate this metric alongside:

- [[wa-dol-firm-license-status|WA DOL Firm License Status]]
- [[trust-accounting-practices|Trust Accounting Practices]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

DOL public records.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
