---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P1
aliases:
tags:
---

# e-o-insurance-carrier-and-limits

## summary

Errors and omissions insurance carrier and coverage limits.

## category

Compliance and Risk (P1 priority)

## what it signals

Litigation resilience.

## how to interpret

Under $1M aggregate is thin for a firm above 200 units.

## benchmark

$1M minimum per claim, $2M aggregate.

## example

$1M per claim / $2M aggregate with A-rated carrier.

## paired metrics

Evaluate this metric alongside:

- [[gl-cyber-coverage|GL Cyber Coverage]]
- [[litigation-history|Litigation History]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Certificate of insurance.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
