---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P2
aliases:
tags:
---

# new-construction-lease-up-capability

## summary

Demonstrated capability to do lease-up of newly built multifamily or build-to-rent product.

## category

Growth and Corporate Development (P2 priority)

## what it signals

Adjacent revenue and developer relationships.

## how to interpret

Niche capability that opens developer relationships and project-based revenue.

## benchmark

Niche.

## example

Has led 3 lease-ups of 50+ unit projects in last 3 years.

## paired metrics

Evaluate this metric alongside:

- [[property-type-mix|Property Type Mix]]
- [[marketing-channels-active|Marketing Channels Active]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Case studies, project list.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
