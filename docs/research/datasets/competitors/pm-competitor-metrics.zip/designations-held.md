---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P1
aliases:
tags:
---

# designations-held

## summary

Industry designations held by firm and staff: CRMC, AMO, ARM, MPM, RMP, CCIM.

## category

Team and Capacity (P1 priority)

## what it signals

Operator quality and credibility. CRMC and AMO are top-tier.

## how to interpret

CRMC is awarded to fewer than 5% of PM firms nationally. Strong signal.

## benchmark

CRMC or AMO = elite.

## example

CRMC firm designation (NARPM) and AMO (IREM) both held vs no designations.

## paired metrics

Evaluate this metric alongside:

- [[associations|Associations]]
- [[leadership-tenure|Leadership Tenure]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

NARPM and IREM public directories.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
