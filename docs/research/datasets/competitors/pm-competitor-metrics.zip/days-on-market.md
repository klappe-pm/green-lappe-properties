---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P0
aliases:
tags:
---

# days-on-market

## summary

Average days from a unit being listed for rent until a lease is signed.

## category

Operational Performance (P0 priority)

## what it signals

Pricing accuracy, marketing reach, leasing process speed. Direct driver of owner economics; every extra day is one day of lost rent.

## how to interpret

Seattle SFR healthy band is 15-30 days. 45+ indicates pricing or photos problem. Under 10 may mean rent is below market.

## benchmark

15-30 days SFR; 7-21 days well-priced units.

## example

Listed 6/1, lease signed 6/17 = 16 days on market. Portfolio average 22 days.

## paired metrics

Evaluate this metric alongside:

- [[vacancy-rate|Vacancy Rate]]
- [[application-to-lease-conversion|Application-to-Lease Conversion]]
- [[showings-per-vacancy|Showings per Vacancy]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[average-tenancy-length|Average Tenancy Length (short DOM + short tenancy = churn-by-design)]]

## source / how to measure

NWMLS, Zillow, firm's own listing data.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
