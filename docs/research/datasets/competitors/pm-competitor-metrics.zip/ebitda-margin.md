---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P1
aliases:
tags:
---

# ebitda-margin

## summary

Operating earnings before interest, taxes, depreciation, and amortization, as a percent of revenue.

## category

Financial Performance (P1 priority)

## what it signals

Operational efficiency and scale economics. Single-location independents with strong tech run higher margin than multi-office traditional firms.

## how to interpret

PM industry runs 10 to 25 percent EBITDA. Below 10 percent signals capacity or pricing problems. Above 30 percent for an independent merits a check on whether reinvestment is happening.

## benchmark

15 to 20 percent healthy independent PM.

## example

Two firms at 1,000 units. Firm A: 22% EBITDA with AppFolio + Property Meld + 250 doors/PM. Firm B: 11% EBITDA with paper-driven ops and 140 doors/PM.

## paired metrics

Evaluate this metric alongside:

- [[doors-per-property-manager|Doors per Property Manager]]
- [[revenue-per-unit|Revenue per Unit]]
- [[maintenance-cost-per-unit|Maintenance Cost per Unit]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[days-on-market|Days on Market (margin earned by deferring maintenance or under-staffing shows up here)]]

## source / how to measure

Owner-disclosed financials during M&A diligence; estimated from headcount + portfolio.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
