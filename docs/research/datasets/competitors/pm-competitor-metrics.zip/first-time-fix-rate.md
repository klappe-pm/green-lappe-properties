---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P2
aliases:
tags:
---

# first-time-fix-rate

## summary

Percent of work orders resolved on the first vendor visit without revisit.

## category

Operational Performance (P2 priority)

## what it signals

Vendor quality, triage accuracy, parts logistics.

## how to interpret

Below 70% signals weak triage or vendor quality issues.

## benchmark

>75% healthy.

## example

100 work orders, 78 closed on first visit = 78%.

## paired metrics

Evaluate this metric alongside:

- [[maintenance-cycle-time|Maintenance Cycle Time]]
- [[maintenance-cost-per-unit|Maintenance Cost per Unit]]
- [[tenant-nps|Tenant NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

PMS work order log.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
