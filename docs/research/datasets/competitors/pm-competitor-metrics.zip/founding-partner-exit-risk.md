---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P1
aliases:
tags:
---

# founding-partner-exit-risk

## summary

Risk that the founder or managing partner will exit the firm in the near term.

## category

Growth and Corporate Development (P1 priority)

## what it signals

Service continuity and owner retention.

## how to interpret

Owner retention dips notably after founder exits without a documented succession plan.

## benchmark

Documented succession lowers risk.

## example

Founder age 68, no documented succession plan, sales brokerage activity suggesting wind-down. Or: 45-year-old founder + named GP successor.

## paired metrics

Evaluate this metric alongside:

- [[tenure-of-leadership|Tenure of Leadership]]
- [[net-unit-growth-rate|Net Unit Growth Rate]]
- [[owner-churn-rate|Owner Churn Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Founder age, equity holders, recent transactions.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
