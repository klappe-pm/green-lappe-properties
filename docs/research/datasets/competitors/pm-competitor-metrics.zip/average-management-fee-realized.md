---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P0
aliases:
tags:
---

# average-management-fee-realized

## summary

Effective management fee actually collected as a percentage of rent, after discounts, minimums, vacancies, and ancillaries are netted out. The realized fee usually differs from the advertised fee.

## category

Financial Performance (P0 priority)

## what it signals

The true price of the service. Useful for comparing across firms when published rates differ by structure.

## how to interpret

Always compute realized fee using a representative unit at market rent. Differences of 1 to 2 points between advertised and realized are normal. Differences of 3+ points indicate pricing opacity.

## benchmark

Seattle realized: 9 to 12 percent typical SFR.

## example

Firm advertises 8% but applies $150/unit minimum, which pushes realized fee to 9.4% on a $1,600 rental. Add $250/yr ancillary and the all-in is closer to 10.7%.

## paired metrics

Evaluate this metric alongside:

- [[mgmt-fee-advertised|Mgmt Fee % Advertised]]
- [[ancillary-revenue-per-unit|Ancillary Revenue per Unit]]
- [[owner-concentration|Owner Concentration]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[net-unit-growth|Net Unit Growth (a firm with widening realized vs advertised may be losing owners)]]

## source / how to measure

Owner statement audit; sample mgmt agreement; competitive shop calls.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
