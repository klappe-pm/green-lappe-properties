---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P0
aliases:
tags:
---

# property-manager-count

## summary

Total number of licensed property managers at the firm.

## category

Team and Capacity (P0 priority)

## what it signals

Service capacity ceiling.

## how to interpret

Build doors/PM ratio. PMs are the binding constraint on growth without tech investment.

## benchmark

Sized to maintain 150-250 doors/PM.

## example

4 PMs for 1,000 units.

## paired metrics

Evaluate this metric alongside:

- [[doors-per-property-manager|Doors per Property Manager]]
- [[total-headcount|Total Headcount]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

LinkedIn.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
