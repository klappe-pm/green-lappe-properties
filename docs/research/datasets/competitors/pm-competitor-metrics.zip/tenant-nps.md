---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: reputation-and-customer-experience
priority-tier: P1
aliases:
tags:
---

# tenant-nps

## summary

Net Promoter Score from tenant survey.

## category

Reputation and Customer Experience (P1 priority)

## what it signals

Renewal predictor. Drives renewal rate and turnover cost.

## how to interpret

Above 20 is healthy. Tenant NPS tends to run lower than owner NPS structurally.

## benchmark

>20 healthy.

## example

Tenant NPS 28 vs 5.

## paired metrics

Evaluate this metric alongside:

- [[renewal-rate|Renewal Rate]]
- [[maintenance-cycle-time|Maintenance Cycle Time]]
- [[communication-sla|Communication SLA]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Tenant survey; review sentiment proxy.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
