---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: service-and-pricing-depth
priority-tier: P2
aliases:
tags:
---

# inspection-types-included

## summary

Which inspection types are bundled into management fee vs upcharged (move-in, move-out, periodic, drive-by, emergency).

## category

Service and Pricing Depth (P2 priority)

## what it signals

Pricing transparency and asset protection commitment.

## how to interpret

Move-in/out should be bundled. Annual interior bundled is the differentiator.

## benchmark

Move-in/out + annual interior bundled.

## example

Firm A: move-in/out + annual included. Firm B: move-in/out included; annual is $125 upcharge.

## paired metrics

Evaluate this metric alongside:

- [[inspection-cadence|Inspection Cadence]]
- [[pricing-transparency|Pricing Transparency]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Management agreement.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
