---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P1
aliases:
tags:
---

# litigation-history

## summary

Civil cases naming the firm as defendant, especially habitability, security deposit, and discrimination matters.

## category

Compliance and Risk (P1 priority)

## what it signals

Reputational and operational risk.

## how to interpret

More than 5 active cases for a sub-2,000-unit firm is a signal of process gaps.

## benchmark

<3 active for healthy firm.

## example

Two active habitability cases and three resolved security deposit disputes in 24 months.

## paired metrics

Evaluate this metric alongside:

- [[ag-complaints|AG Complaints]]
- [[doj-hud-complaints|DOJ HUD Complaints]]
- [[lease-compliance-incidents|Lease Compliance Incidents]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

King and Snohomish County Superior Court records.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
