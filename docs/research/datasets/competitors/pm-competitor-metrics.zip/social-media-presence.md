---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: strategic-positioning
priority-tier: P2
aliases:
tags:
---

# social-media-presence

## summary

Active social profiles on Facebook, LinkedIn, Instagram, YouTube, TikTok.

## category

Strategic Positioning (P2 priority)

## what it signals

Brand investment and reach.

## how to interpret

Active LinkedIn is most valuable for owner acquisition. Instagram and YouTube valuable for tenant brand.

## benchmark

2+ active platforms.

## example

Active LinkedIn + Facebook + Instagram. Or: dormant profiles on all.

## paired metrics

Evaluate this metric alongside:

- [[content-velocity|Content Velocity]]
- [[marketing-channels-active|Marketing Channels Active]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Manual check.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
