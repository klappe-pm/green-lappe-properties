---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P0
aliases:
tags:
---

# delinquency-rate

## summary

Percent of rent more than 30 days past due as of month end.

## category

Operational Performance (P0 priority)

## what it signals

Screening rigor, communication discipline, and eviction policy effectiveness.

## how to interpret

Above 5% indicates screening or communication breakdown. Track trend; a sudden spike often precedes economic stress in the rent roll.

## benchmark

<3% healthy.

## example

$1.2M monthly rent roll, $40K aged 30+ = 3.3% delinquency.

## paired metrics

Evaluate this metric alongside:

- [[rent-collection-rate|Rent Collection Rate]]
- [[eviction-rate-per-100-units|Eviction Rate per 100 Units]]
- [[credit-score-min|Credit Score Min]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[days-on-market|Days on Market (loose screening to fill faster shows up as delinquency)]]

## source / how to measure

PMS aged receivables report.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
