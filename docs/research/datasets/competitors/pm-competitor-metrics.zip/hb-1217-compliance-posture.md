---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P0
aliases:
tags:
---

# hb-1217-compliance-posture

## summary

Adherence to Washington's 2025 statewide rent stabilization (HB 1217) limiting annual rent increases.

## category

Compliance and Risk (P0 priority)

## what it signals

Up-to-date regulatory awareness.

## how to interpret

Operating in WA without 1217 compliance is a litigation magnet starting 2025.

## benchmark

Required statewide.

## example

Firm has updated all renewal notices, lease forms, and notice templates. Or: still using pre-1217 templates.

## paired metrics

Evaluate this metric alongside:

- [[seattle-compliance-posture|Seattle Compliance Posture]]
- [[lease-compliance-incidents|Lease Compliance Incidents]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website; sample lease and renewal notice.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
