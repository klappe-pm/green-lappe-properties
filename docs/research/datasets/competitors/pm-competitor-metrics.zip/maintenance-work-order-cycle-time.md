---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# maintenance-work-order-cycle-time

## summary

Average days from work order opened to closed (excluding emergencies).

## category

Operational Performance (P1 priority)

## what it signals

Operational throughput, vendor coordination, tenant satisfaction.

## how to interpret

Under 7 days for non-emergency is healthy. Over 14 days creates tenant churn.

## benchmark

<7 days non-emergency.

## example

Non-emergency average 5.2 days.

## paired metrics

Evaluate this metric alongside:

- [[first-time-fix-rate|First-Time Fix Rate]]
- [[emergency-response-time|Emergency Response Time]]
- [[tenant-nps|Tenant NPS]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

PMS work order timestamps.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
