---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P1
aliases:
tags:
---

# renewal-rate

## summary

Percent of leases that renew at end of term (rather than the tenant moving out).

## category

Operational Performance (P1 priority)

## what it signals

Tenant satisfaction, rent positioning, property condition. Renewals avoid the cost and risk of turn.

## how to interpret

60-75% is healthy SFR. Above 85% may indicate under-priced rent. Below 50% indicates retention problem.

## benchmark

60-75% healthy SFR.

## example

120 leases up for renewal, 78 renewed = 65% renewal rate.

## paired metrics

Evaluate this metric alongside:

- [[average-tenancy-length|Average Tenancy Length]]
- [[tenant-nps|Tenant NPS]]
- [[days-on-market|Days on Market]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[rent-collection-rate|Rent Collection Rate (renewing at any cost masks bad tenants)]]

## source / how to measure

PMS renewal tracking.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
