---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P1
aliases:
tags:
---

# ag-complaints

## summary

Washington State Attorney General consumer protection complaints filed against the firm.

## category

Compliance and Risk (P1 priority)

## what it signals

Regulatory exposure and consumer-protection profile.

## how to interpret

Zero is the only acceptable target. Even one open AG complaint is a serious due diligence item.

## benchmark

0 preferred.

## example

Zero complaints in 5 years vs two complaints regarding security deposit returns.

## paired metrics

Evaluate this metric alongside:

- [[bbb-complaint-count|BBB Complaint Count]]
- [[litigation-history|Litigation History]]
- [[doj-hud-complaints|DOJ HUD Complaints]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

AG public records.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
