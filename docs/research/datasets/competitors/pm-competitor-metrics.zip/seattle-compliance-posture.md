---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: compliance-and-risk
priority-tier: P0
aliases:
tags:
---

# seattle-compliance-posture

## summary

Adherence to Seattle-specific ordinances: SMC 14.09 Fair Chance Housing, RRIO, First-in-Time, Just Cause, 180-day rent increase notice.

## category

Compliance and Risk (P0 priority)

## what it signals

Operating capability in Seattle. Seattle has the densest landlord ordinance stack in WA.

## how to interpret

Required to operate in Seattle. Missing any of the five creates litigation exposure.

## benchmark

Full compliance language.

## example

All five ordinances visibly addressed in screening criteria, lease form, and notice templates.

## paired metrics

Evaluate this metric alongside:

- [[hb-1217-compliance-posture|HB 1217 Compliance Posture]]
- [[lease-compliance-incidents|Lease Compliance Incidents]]
- [[ag-complaints|AG Complaints]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Website; screening criteria PDF; sample lease.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
