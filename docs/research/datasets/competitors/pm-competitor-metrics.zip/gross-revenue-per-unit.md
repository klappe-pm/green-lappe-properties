---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: financial-performance
priority-tier: P0
aliases:
tags:
---

# gross-revenue-per-unit

## summary

Total annual revenue divided by units under management. Includes management fees, leasing fees, ancillary income.

## category

Financial Performance (P0 priority)

## what it signals

Composite measure of pricing power and ancillary capture. Comparable across firms.

## how to interpret

Use it as the single comparator when pricing structures vary. Pair with door count for total revenue benchmark.

## benchmark

$1,800 to $3,200 per unit per year typical SFR Seattle.

## example

1,000 units @ $2,200 average rent. At 10% management + 50% of one month leasing on 25% turnover + $250/unit ancillary: revenue per unit = $2,640 + $275 + $250 = $3,165.

## paired metrics

Evaluate this metric alongside:

- [[average-management-fee-realized|Average Management Fee Realized]]
- [[ancillary-revenue-per-unit|Ancillary Revenue per Unit]]
- [[average-rent-per-unit|Average Rent per Unit]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- [[owner-nps|Owner NPS]]

## source / how to measure

Calculated from advertised pricing applied to typical portfolio; validated via owner interviews.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
