---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: portfolio-composition
priority-tier: P1
aliases:
tags:
---

# geographic-concentration

## summary

Units per ZIP code or top-ZIP share of total portfolio.

## category

Portfolio Composition (P1 priority)

## what it signals

Density advantage (faster vendor dispatch, lower windshield time) vs geographic risk.

## how to interpret

Concentration helps unit economics. Excessive concentration creates exposure to neighborhood-level events.

## benchmark

30-50% in top ZIP healthy for an independent.

## example

Firm: 40% of 1,000 units in three ZIPs (98103, 98115, 98117).

## paired metrics

Evaluate this metric alongside:

- [[doors-per-property-manager|Doors per Property Manager]]
- [[maintenance-cycle-time|Maintenance Cycle Time]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Firm portfolio map; NWMLS rental records.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
