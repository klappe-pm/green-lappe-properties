---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: operational-performance
priority-tier: P2
aliases:
tags:
---

# time-to-first-showing

## summary

Hours or days from listing publication to first scheduled showing.

## category

Operational Performance (P2 priority)

## what it signals

Marketing reach and inquiry velocity.

## how to interpret

Under 48 hours is healthy in PNW SFR; longer indicates marketing reach gap.

## benchmark

<48 hours.

## example

Listed Friday 10am, first showing Saturday 11am = 25 hours.

## paired metrics

Evaluate this metric alongside:

- [[days-on-market|Days on Market]]
- [[marketing-channels-active|Marketing Channels Active]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Self-showing platform.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
