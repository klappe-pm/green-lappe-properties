---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: team-and-capacity
priority-tier: P1
aliases:
tags:
---

# tenure-of-leadership

## summary

Years the current principal or executive team has led the firm.

## category

Team and Capacity (P1 priority)

## what it signals

Stability and succession risk.

## how to interpret

Long tenure correlates with stable owner relationships. Recent change warrants follow-up on owner retention.

## benchmark

5+ years.

## example

Founder + 15 years vs new managing partner after sale.

## paired metrics

Evaluate this metric alongside:

- [[designated-broker-license-and-tenure|Designated Broker License and Tenure]]
- [[net-unit-growth-rate|Net Unit Growth Rate]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

LinkedIn, founder bio.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
