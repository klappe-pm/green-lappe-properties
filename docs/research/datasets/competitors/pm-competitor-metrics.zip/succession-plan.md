---
domain: green-lappe-properties
category: market-research
sub-category: competitor-metrics
date-created: 2026-05-18
date-revised: 2026-05-18
doc-type: metric-definition
metric-category: growth-and-corporate-development
priority-tier: P1
aliases:
tags:
---

# succession-plan

## summary

Documented succession arrangement for the principal and designated broker roles.

## category

Growth and Corporate Development (P1 priority)

## what it signals

Business continuity and owner retention through transitions.

## how to interpret

Absence of named successor is a material risk for any firm with founder over 60.

## benchmark

Documented.

## example

Family succession with daughter as managing member, both license-active. Or: solo broker with no successor named.

## paired metrics

Evaluate this metric alongside:

- [[founding-partner-exit-risk|Founding Partner Exit Risk]]
- [[designated-broker-license-and-tenure|Designated Broker License and Tenure]]

## counter-metrics

Watch for these metrics moving in the opposite direction, which indicates the headline metric is being gamed or compensated for:

- (none)

## source / how to measure

Firm disclosure; founder interview.

## see also

- [[pm-competitor-metrics-index|metric catalog]]
